export const MUSICNAME = "Music";

export const BASE_URL = process.env.NODE_HOST;

// export const BASE_URL = process.env.NODE_HOST;