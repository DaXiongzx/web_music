// 轮播图
export const swiperList = [
  {
    picImg: require("@/assets/images/swiper/podcasts-music-copyrights.jpg"),
  },
  {
    picImg: require("@/assets/images/swiper/recordalbum2-100616490-large.jpg"),
  },
  {
    picImg: require("@/assets/images/swiper/Roxy-Music.jpg"),
  },
  {
    picImg: require("@/assets/images/swiper/R-C.jpg"),
  },
  // {
  //   picImg: require("@/assets/images/swiper/microphone-1209816_640.jpg"),
  // },
  // {
  //   picImg: require("@/assets/images/swiper/music-notes-3221097_640.jpg"),
  // },
  // {
  //   picImg: require("@/assets/images/swiper/piano-1655558_640.jpg"),
  // },
  // {
  //   picImg: require("@/assets/images/swiper/turntable-1337986_640.jpg"),
  // },
];
