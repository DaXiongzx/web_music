<template>
  <div class="setting">
    <h1>敬请期待</h1>
  </div>
</template>

<style lang="scss" scoped>
@import "@/assets/css/var.scss";
@import "@/assets/css/global.scss";

.setting {
  margin: 30px 10%;
  margin-top: 0;
  padding-top: $header-height;
  min-height: 60vh;
  background-color: $color-white;
  border-radius: 12px;
  text-align: center;
}
</style>
